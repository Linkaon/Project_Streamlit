import pandas as pd
import streamlit as st
import plotly.express as px
import plotly.graph_objects as pgo

st.title('Streamit test')
df = pd.read_excel('liste-des-films-sortis-dans-les-salles-de-cinema-en-france-de-1945-a-2020.xlsx')
st.dataframe(df)




df['Format'] = df['Format'].fillna('Non renseigné')

df['Format'] = df['Format'].replace(1954, 'Court-métrage')
df['Format'] = df['Format'].replace('États-Unis', 'Long-métrage')
df['Format'] = df['Format'].replace('France]', 'Court-métrage')
df['Format'] = df['Format'].replace('France-Italie', 'Court-métrage')
df['Format'] = df['Format'].replace('-', 'Court-métrage')
df.loc[df['Format'].str.contains('Long-métrage', case=False)] = 'Long-métrage'


df.loc[40976, 'Format'] = 'Court-métrage'

df['Date de sortie'] = df['Date de sortie'].replace('Brésil', 1968)
df['Date de sortie'] = df['Date de sortie'].dropna()
df['Nationalité'] = df['Nationalité'].replace(1948, 'Royaume-Uni')

count_film = df.groupby('Date de sortie').size().reset_index(name='count film')
plot = pgo.Figure(data=[pgo.Scatter(
    x=count_film['Date de sortie'],
    y=count_film['count film'],
    mode='markers')])

plot.update_layout(
    updatemenus=[
        dict(
            buttons=list([
                dict(
                    args=['type', 'scatter'],
                    label='Scatter plot',
                    method='restyle', ),
                dict(
                    args=['type', 'bar'],
                    label='Bar plot',
                    method='restyle')
            ]),
            direction='down')
    ])

st.plotly_chart(plot, use_container_width=True)

count_film_country = df.groupby('Nationalité').size().reset_index(name='count films')
print(count_film_country)

for i in range(len(count_film_country)):
    a = count_film_country.loc[i, 'Nationalité']
    arr = a.split(" - ")
    count_film_country.loc[i, 'Pays'] = arr[0]

cfc = count_film_country.groupby('Pays').size().reset_index(name = 'cfc')

cfc.loc[cfc['Pays'].str.contains('Allemagne', case=False), 'Pays'] = 'Allemagne'
cfc.loc[cfc['Pays'].str.contains('Canada', case=False), 'Pays'] = 'Canada'
cfc.loc[cfc['Pays'].str.contains('Espagne', case=False), 'Pays'] = 'Espagne'
cfc.loc[cfc['Pays'].str.contains('France', case=False), 'Pays'] = 'France'
cfc.loc[cfc['Pays'].str.contains('Hongrie', case=False), 'Pays'] = 'Hongrie'
cfc.loc[cfc['Pays'].str.contains('Pologne', case=False), 'Pays'] = 'Pologne'
cfc.loc[cfc['Pays'].str.contains('Royaume-Uni', case=False), 'Pays'] = 'Royaume-Uni'
cfc.loc[cfc['Pays'].str.contains('Russie', case=False), 'Pays'] = 'Russie'
cfc.loc[cfc['Pays'].str.contains('Égypte', case=False), 'Pays'] = 'Égypte'
cfc.loc[cfc['Pays'].str.contains('États-Unis', case=False), 'Pays'] = 'États-Unis'
cfc.loc[cfc['Pays'].str.contains('Albanie', case=False), 'Pays'] = 'Albanie'
cfc.loc[cfc['Pays'].str.contains('Australie', case=False), 'Pays'] = 'Australie'
cfc.loc[cfc['Pays'].str.contains('Autriche', case=False), 'Pays'] = 'Autriche'
cfc.loc[cfc['Pays'].str.contains('Belgique', case=False), 'Pays'] = 'Belgique'
cfc.loc[cfc['Pays'].str.contains('Brésil', case=False), 'Pays'] = 'Brésil'
cfc.loc[cfc['Pays'].str.contains('Chine', case=False), 'Pays'] = 'Chine'
cfc.loc[cfc['Pays'].str.contains('Danemark', case=False), 'Pays'] = 'Danemark'
cfc.loc[cfc['Pays'].str.contains('Grèce', case=False), 'Pays'] = 'Grèce'
cfc.loc[cfc['Pays'].str.contains('Hong-Kong', case=False), 'Pays'] = 'Hong-Kong'
cfc.loc[cfc['Pays'].str.contains('Irtalie', case=False), 'Pays'] = 'Italie'
cfc.loc[cfc['Pays'].str.contains('Italie', case=False), 'Pays'] = 'Italie'
cfc.loc[cfc['Pays'].str.contains('Japon', case=False), 'Pays'] = 'Japon'
cfc.loc[cfc['Pays'].str.contains('Lettonie', case=False), 'Pays'] = 'Lettonie'
cfc.loc[cfc['Pays'].str.contains('Mexique', case=False), 'Pays'] = 'Mexique'
cfc.loc[cfc['Pays'].str.contains('Norvège', case=False), 'Pays'] = 'Norvège'
cfc.loc[cfc['Pays'].str.contains('Nouvelle Zélande', case=False), 'Pays'] = 'Nouvelle Zélande'
cfc.loc[cfc['Pays'].str.contains('Nouvelle-Zélande', case=False), 'Pays'] = 'Nouvelle Zélande'
cfc.loc[cfc['Pays'].str.contains('Sri-Lanka', case=False), 'Pays'] = 'Sri Lanka'
cfc.loc[cfc['Pays'].str.contains('Suède', case=False), 'Pays'] = 'Suède'
cfc.loc[cfc['Pays'].str.contains('Sénégal', case=False), 'Pays'] = 'Sénégal'
cfc.loc[cfc['Pays'].str.contains('Tchécoslovaquie', case=False), 'Pays'] = 'Tchécoslovaquie'
cfc.loc[cfc['Pays'].str.contains('Tchécoslovaque', case=False), 'Pays'] = 'Tchécoslovaquie'
cfc.loc[cfc['Pays'].str.contains('Ukraine', case=False), 'Pays'] = 'Ukraine'
cfc.loc[cfc['Pays'].str.contains('Viêt Nam', case=False), 'Pays'] = 'Viêt Nam'
cfc.loc[cfc['Pays'].str.contains('Vietnam', case=False), 'Pays'] = 'Viêt Nam'
cfc.loc[cfc['Pays'].str.contains('Yougoslavie', case=False), 'Pays'] = 'Yougoslavie'
cfc.loc[cfc['Pays'].str.contains('États-Uni', case=False), 'Pays'] = 'États-Unis'


translations = ['Germany', 'Canada', 'Spain', 'France', 'Hungary', 'Poland', 'United Kingdom', 'Russia', 'Egypt', 'United States', 'South Africa', 'Albania', 'Algeria', 'Argentina', 'Armenia', 'Australia', 'Austria', 'Belgium', 'Brazil', 'Bulgaria', 'Burkina Faso', 'Central African Republic', 'Cambodia', 'Chile', 'China', 'Colombia', 'North Korea', 'South Korea', 'Croatia', 'Cuba', 'Denmark', 'Finland', 'Greece', 'Guinea', 'Hong Kong', 'India', 'Iran', 'Ireland', 'Iceland', 'Israel', 'Italy', 'Japan', 'Jordan', 'Latvia', 'Lebanon', 'Feature Film', 'Luxembourg', 'Malaysia', 'Mali', 'Morocco', 'Mexico', 'Moldova', 'Monaco', 'Mongolia', 'Not specified', 'Norway', 'New Zealand', 'Netherlands', 'Philippines', 'Puerto Rico', 'Portugal', 'Red Star Cinema', 'Rhodesia', 'Romania', 'Czech Republic', 'Slovakia', 'Sri Lanka', 'Switzerland', 'Switzerland', 'Sweden', 'Senegal', 'Czechoslovakia', 'Thailand', 'Togo', 'Tunisia', 'Turkey', 'Ukraine', 'Uruguay', 'Vietnam', 'Yugoslavia']


list_corr = cfc['Pays'].unique()
print(len(list_corr))
print(len(translations))
dico_corr = {}
for i in range(80):
    dico_corr[list_corr[i]] = translations[i]

cfc['Country'] = cfc['Pays'].map(dico_corr)
country_codes = ['DE', 'CA', 'ES', 'FR', 'HU', 'PL', 'GB', 'RU', 'EG', 'US', 'ZA', 'AL', 'DZ', 'AR', 'AM', 'AU', 'AT', 'BE', 'BR', 'BG', 'BF', 'CF', 'KH', 'CL', 'CN', 'CO', 'KP', 'KR', 'HR', 'CU', 'DK', 'FI', 'GR', 'GN', 'HK', 'IN', 'IR', 'IE', 'IS', 'IL', 'IT', 'JP', 'JO', 'LV', 'LB', 'Feature Film', 'LU', 'MY', 'ML', 'MA', 'MX', 'MD', 'MC', 'MN', 'Not specified', 'NO', 'NZ', 'NL', 'PH', 'PR', 'PT', 'Red Star Cinema', 'Rhodesia', 'RO', 'CZ', 'SK', 'LK', 'CH', 'CH', 'SE', 'SN', 'CS', 'TH', 'TG', 'TN', 'TR', 'UA', 'UY', 'VN', 'YU']

for i in range(80):
    cfc.loc[i, 'CodePays'] = country_codes[i]
fig = px.scatter_geo(cfc, locations="CodePays", color="Pays",
                     hover_name="Pays", size="cfc",
                     projection="natural earth")

st.plotly_chart(fig, use_container_width=True)
fig.show()
list_cp = ['DEU',
 'CAN',
 'ESP',
 'FRA',
 'FRA',
 'HUN',
 'POL',
 'GBR',
 None,
 'EGY',
 'USA',
 'AFG',
 'ZAF',
 'ALB',
 'ALB',
 'DZA',
 'DEU',
 'DEU',
 'ARG',
 'ARM',
 'AUS',
 'AUS',
 'AUT',
 'AUT',
 'BEL',
 'BEL',
 'BTN',
 None,
 'BIH',
 'BRA',
 'BRA',
 'BGR',
 'BFA',
 'BEN',
 'CMR',
 'KHM',
 'CMR',
 'CAN',
 'CAN',
 'CHL',
 'CHN',
 'CHN',
 'COL',
 None,
 None,
 'HRV',
 'CUB',
 'DNK',
 'DNK',
 'ESP',
 'ESP',
 'EST',
 'FIN',
 'FRA',
 'FRA',
 'DEU',
 'FRA',
 'FRA',
 'FRA',
 'FRA',
 'FRA',
 'GAB',
 'GRC',
 'GRC',
 'GIN',
 'GNB',
 'GEO',
 'HKG',
 'HKG',
 'HUN',
 'IND',
 'IDN',
 None,
 'IRL',
 'ITA',
 'ISL',
 'ISR',
 'ISR',
 'ITA',
 'ITA',
 'FRA',
 'JAM',
 'JPN',
 'JPN',
 'JOR',
 'KAZ',
 'LVA',
 'LVA',
 'LBN',
 'LBN',
 'LBY',
 'LTU',
 'LUX',
 None,
 'MYS',
 'MLI',
 'MAR',
 'MEX',
 'MEX',
 None,
 'MCO',
 'MNG',
 'MOZ',
 None,
 None,
 'NOR',
 'NOR',
 'NZL',
 'NZL',
 'NZL',
 'NZL',
 None,
 'PAN',
 'PRY',
 'NLD',
 None,
 'PHL',
 'POL',
 'POL',
 None,
 'PRT',
 'PER',
 None,
 None,
 'ROU',
 'GBR',
 'GBR',
 'FRA',
 'DEU',
 None,
 None,
 None,
 None,
 'DOM',
 None,
 None,
 'SRB',
 'SGP',
 'SVK',
 'SVN',
 'LKA',
 'LKA',
 'CHE',
 'CHE',
 'SWE',
 'SWE',
 None,
 'SEN',
 'SEN',
 None,
 None,
 None,
 None,
 None,
 'THA',
 'TGO',
 'TUN',
 'TUR',
 'UKR',
 'UKR',
 'URY',
 None,
 None,
 None,
 None,
 None,
 None,
 None,
 'EGY',
 'EGY',
 'USA',
 'USA',
 'USA']

for i in range(len(cfc)):
    cfc.loc[i, 'CodePays'] = list_cp[i]

st.code(cfc)