import pandas as pd
import streamlit as st
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np

with st.sidebar:
    st.write("Author:")
    st.write("ANDRE Noa")
    st.write("Efrei Paris - Promo 2025")
    st.write('<span style="color: red; font-size: 20px;"> #datavz2023efrei </span>',
             unsafe_allow_html=True)

    image_path = '../GitHub_logo.png'
    left_co, cent_co, last_co = st.columns(3)
    with cent_co:
        st.image(image_path)
    st.write('<span style="color: gray; font-size: 13px;"> https://github.com/Linkaon </span>',
             unsafe_allow_html=True)

    image_path = '../linkedin.png'
    left_co, cent_co, last_co = st.columns(3)  # to center the logo
    with cent_co:
        st.image(image_path, width=50)
    st.write('<span style="color: gray; font-size: 13px;"> www.linkedin.com/in/emmadeste/ </span>',
             unsafe_allow_html=True)


st.title("Now, let's take a look to the :green[__visa__] for films")
df = pd.read_excel('csv1.xlsx')
st.dataframe(df)
df['Format'].fillna('Non renseigné')
df['Format'] = df['Format'].replace(1954, 'Court-métrage')
df['Format'] = df['Format'].replace('États-Unis', 'Long-métrage')
df['Format'] = df['Format'].replace('France]', 'Court-métrage')
df['Format'] = df['Format'].replace('France-Italie', 'Long-métrage')
df['Format'] = df['Format'].replace('-', 'Court-métrage')
df.loc[df['Format'].str.contains('Long-métrage', case=False), 'Format'] = 'Long-métrage'

df['Date de sortie'] = df['Date de sortie'].replace('Brésil', 1968)

df['Nationalité'] = df['Nationalité'].replace(1948, 'Royaume-Uni')
df.loc[40976, 'Format'] = 'Court-métrage'

df['Date de sortie'] = df['Date de sortie'].replace('Non renseigné', 0)
df['Date de sortie'] = df['Date de sortie'].replace(np.nan, 0)
df_copy = df.copy()

df_copy.drop(df_copy[df_copy['Date de sortie'] == 0].index, inplace=True)
df_copy['Date de sortie'] = df_copy['Date de sortie'].astype(int)
df2 = df_copy.sort_values(by='Date de sortie')
test = plt.figure(figsize=(10, 6))
ax = sns.countplot(x='Date de sortie', hue="Localisation du dossier de visa d'exploitation", data=df2, palette='Set1')

plt.xlabel('Année de sortie')
plt.ylabel('Nombre de visas')
plt.title('Graphique des visas en fonction de l\'année de sortie')

plt.legend(title='Visa', loc='upper right')
plt.xticks(rotation=90)
plt.tight_layout()
# plt.show()
st.title('Type of :green[__Visa__] over years')
st.pyplot(test)
st.write('☯️There is only two type of visa in France: **Archives Nationales** and **CNC**')
st.write('🎢**Archives Nationales** declines over years, instead of **CNC**')

st.title('Count of :green[__Visa__] over years')
grouped_data = df2.groupby(['Date de sortie', "Localisation du dossier de visa d'exploitation"]).size().unstack().fillna(0)
st.area_chart(grouped_data)

st.write('🪪We can see the evolution of the two types of Visa')
st.write('🎦**Archives Nationales** was very popular in 1940-1950, but now, there is only **CNC**')