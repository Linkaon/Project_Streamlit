import pandas as pd
import seaborn as sns
import streamlit as st
import matplotlib.pyplot as plt
import plotly.express as px
import numpy as np

with st.sidebar:
    st.write("Author:")
    st.write("ANDRE Noa")
    st.write("Efrei Paris - Promo 2025")
    st.write('<span style="color: red; font-size: 20px;"> #datavz2023efrei </span>',
             unsafe_allow_html=True)

    image_path = '../GitHub_logo.png'
    left_co, cent_co, last_co = st.columns(3)
    with cent_co:
        st.image(image_path)
    st.write('<span style="color: gray; font-size: 13px;"> https://github.com/Linkaon </span>',
             unsafe_allow_html=True)

    image_path = '../linkedin.png'
    left_co, cent_co, last_co = st.columns(3)  # to center the logo
    with cent_co:
        st.image(image_path, width=50)
    st.write('<span style="color: gray; font-size: 13px;"> www.linkedin.com/in/emmadeste/ </span>',
             unsafe_allow_html=True)

st.title("Now, let's take a look to the :blue[__format__] of film")
df = pd.read_excel('csv1.xlsx')
st.dataframe(df)
df['Format'].fillna('Non renseigné')
df['Format'] = df['Format'].replace(1954, 'Court-métrage')
df['Format'] = df['Format'].replace('États-Unis', 'Long-métrage')
df['Format'] = df['Format'].replace('France]', 'Court-métrage')
df['Format'] = df['Format'].replace('France-Italie', 'Long-métrage')
df['Format'] = df['Format'].replace('-', 'Court-métrage')
df.loc[df['Format'].str.contains('Long-métrage', case = False), 'Format'] = 'Long-métrage'

df['Date de sortie'] = df['Date de sortie'].replace('Brésil', 1968)

df['Nationalité'] = df['Nationalité'].replace(1948, 'Royaume-Uni')
df.loc[40976, 'Format'] = 'Court-métrage'


count_film_country = df.groupby('Nationalité').size().reset_index(name = 'count films')
for i in range(len(count_film_country)):
    a = count_film_country.loc[i, 'Nationalité']
    arr = a.split(" - ")
    count_film_country.loc[i, 'Pays'] = arr[0]
cfc = count_film_country.groupby('Pays').size().reset_index(name = 'cfc')

cfc.loc[cfc['Pays'].str.contains('Allemagne', case = False), 'Pays'] = 'Allemagne'
cfc.loc[cfc['Pays'].str.contains('Canada', case = False), 'Pays'] = 'Canada'
cfc.loc[cfc['Pays'].str.contains('Espagne', case = False), 'Pays'] = 'Espagne'
cfc.loc[cfc['Pays'].str.contains('France', case = False), 'Pays'] = 'France'
cfc.loc[cfc['Pays'].str.contains('Hongrie', case = False), 'Pays'] = 'Hongrie'
cfc.loc[cfc['Pays'].str.contains('Pologne', case = False), 'Pays'] = 'Pologne'
cfc.loc[cfc['Pays'].str.contains('Royaume-Uni', case = False), 'Pays'] = 'Royaume-Uni'
cfc.loc[cfc['Pays'].str.contains('Russie', case = False), 'Pays'] = 'Russie'
cfc.loc[cfc['Pays'].str.contains('Égypte', case = False), 'Pays'] = 'Égypte'
cfc.loc[cfc['Pays'].str.contains('États-Unis', case = False), 'Pays'] = 'États-Unis'
cfc.loc[cfc['Pays'].str.contains('Albanie', case = False), 'Pays'] = 'Albanie'
cfc.loc[cfc['Pays'].str.contains('Australie', case = False), 'Pays'] = 'Australie'
cfc.loc[cfc['Pays'].str.contains('Autriche', case = False), 'Pays'] = 'Autriche'
cfc.loc[cfc['Pays'].str.contains('Belgique', case = False), 'Pays'] = 'Belgique'
cfc.loc[cfc['Pays'].str.contains('Brésil', case = False), 'Pays'] = 'Brésil'
cfc.loc[cfc['Pays'].str.contains('Chine', case = False), 'Pays'] = 'Chine'
cfc.loc[cfc['Pays'].str.contains('Danemark', case = False), 'Pays'] = 'Danemark'
cfc.loc[cfc['Pays'].str.contains('Grèce', case = False), 'Pays'] = 'Grèce'
cfc.loc[cfc['Pays'].str.contains('Hong-Kong', case = False), 'Pays'] = 'Hong-Kong'
cfc.loc[cfc['Pays'].str.contains('Irtalie', case = False), 'Pays'] = 'Italie'
cfc.loc[cfc['Pays'].str.contains('Italie', case = False), 'Pays'] = 'Italie'
cfc.loc[cfc['Pays'].str.contains('Japon', case = False), 'Pays'] = 'Japon'
cfc.loc[cfc['Pays'].str.contains('Lettonie', case = False), 'Pays'] = 'Lettonie'
cfc.loc[cfc['Pays'].str.contains('Mexique', case = False), 'Pays'] = 'Mexique'
cfc.loc[cfc['Pays'].str.contains('Norvège', case = False), 'Pays'] = 'Norvège'
cfc.loc[cfc['Pays'].str.contains('Nouvelle Zélande', case = False), 'Pays'] = 'Nouvelle Zélande'
cfc.loc[cfc['Pays'].str.contains('Nouvelle-Zélande', case = False), 'Pays'] = 'Nouvelle Zélande'
cfc.loc[cfc['Pays'].str.contains('Sri-Lanka', case = False), 'Pays'] = 'Sri Lanka'
cfc.loc[cfc['Pays'].str.contains('Suède', case = False), 'Pays'] = 'Suède'
cfc.loc[cfc['Pays'].str.contains('Sénégal', case = False), 'Pays'] = 'Sénégal'
cfc.loc[cfc['Pays'].str.contains('Tchécoslovaquie', case = False), 'Pays'] = 'Tchécoslovaquie'
cfc.loc[cfc['Pays'].str.contains('Tchécoslovaque', case = False), 'Pays'] = 'Tchécoslovaquie'
cfc.loc[cfc['Pays'].str.contains('Ukraine', case = False), 'Pays'] = 'Ukraine'
cfc.loc[cfc['Pays'].str.contains('Viêt Nam', case = False), 'Pays'] = 'Viêt Nam'
cfc.loc[cfc['Pays'].str.contains('Vietnam', case = False), 'Pays'] = 'Viêt Nam'
cfc.loc[cfc['Pays'].str.contains('Yougoslavie', case = False), 'Pays'] = 'Yougoslavie'
cfc.loc[cfc['Pays'].str.contains('États-Uni', case = False), 'Pays'] = 'États-Unis'



pays_en_anglais = [
    'Germany', 'Canada', 'Spain', 'France', 'Hungary', 'Poland',
    'United Kingdom', 'Russia', 'Egypt', 'United States', 'Afghanistan',
    'South Africa', 'Albania', 'Algeria', 'Argentina', 'Armenia',
    'Australia', 'Austria', 'Belgium', 'Bhutan', 'Bolivia',
    'Bosnia and Herzegovina', 'Brazil', 'Bulgaria', 'Burkina Faso',
    'Benin', 'Cameroon', 'Cambodia', 'Cameroon', 'Chile', 'China',
    'Colombia', 'North Korea', 'South Korea', 'Croatia', 'Cuba',
    'Denmark', 'Estonia', 'Finland', 'Gabon', 'Greece', 'Guinea',
    'Guinea-Bissau', 'Georgia', 'Hong Kong', 'Hong Kong', 'India',
    'Indonesia', 'Iran', 'Ireland', 'Italy', 'Iceland', 'Israel',
    'Israel', 'Jamaica', 'Japan', 'Jordan', 'Kazakhstan', 'Latvia',
    'Lebanon', 'Lebanon', 'Libya', 'Lithuania', 'Luxembourg',
    'Macedonia', 'Malaysia', 'Mali', 'Morocco', 'Mexico', 'Moldova',
    'Monaco', 'Mongolia', 'Mozambique', 'New Regency Productions',
    'Unknown', 'Norway', 'New Zealand', 'Palestine', 'Panama', 'Paraguay',
    'Netherlands', 'Mark Peploe', 'Philippines', 'Porto Rico', 'Portugal',
    'Peru', 'Red Star Cinema', 'Rhodesia', 'Romania',
    'Dominican Republic', "People's Republic of Angola", 'Czech Republic',
    'Serbia', 'Singapore', 'Slovakia', 'Slovenia', 'Sri Lanka', 'Switzerland',
    'Switzerland', 'Sweden', 'Syria', 'Senegal', 'Taiwan',
    'Czechoslovakia', 'Thailand', 'Togo', 'Tunisia', 'Turkey',
    'Ukraine', 'Uruguay', 'Vatican', 'Venezuela', 'Vietnam', 'Yugoslavia'
]
list_corr = cfc['Pays'].unique()
dico_corr = {}

for i in range(114):
    dico_corr[list_corr[i]] = pays_en_anglais[i]

cfc['Country'] = cfc['Pays'].map(dico_corr)
list_cp = ['DEU', 'CAN', 'ESP', 'FRA', 'FRA', 'HUN', 'POL', 'GBR', None, 'EGY', 'USA', 'AFG', 'ZAF', 'ALB', 'ALB', 'DZA', 'DEU', 'DEU', 'ARG', 'ARM', 'AUS', 'AUS', 'AUT', 'AUT', 'BEL', 'BEL', 'BTN', None, 'BIH', 'BRA', 'BRA', 'BGR', 'BFA', 'BEN', 'CMR', 'KHM', 'CMR', 'CAN', 'CAN', 'CHL', 'CHN', 'CHN', 'COL', None, None, 'HRV', 'CUB', 'DNK', 'DNK', 'ESP', 'ESP', 'EST', 'FIN', 'FRA', 'FRA', 'DEU', 'FRA', 'FRA', 'FRA', 'FRA', 'FRA', 'GAB', 'GRC', 'GRC', 'GIN', 'GNB', 'GEO', 'HKG', 'HKG', 'HUN', 'IND', 'IDN', None, 'IRL', 'ITA', 'ISL', 'ISR', 'ISR', 'ITA', 'ITA', 'FRA', 'JAM', 'JPN', 'JPN', 'JOR', 'KAZ', 'LVA', 'LVA', 'LBN', 'LBN', 'LBY', 'LTU', 'LUX', None, 'MYS', 'MLI', 'MAR', 'MEX', 'MEX', None, 'MCO', 'MNG', 'MOZ', None, None, 'NOR', 'NOR', 'NZL', 'NZL', 'NZL', 'NZL', None, 'PAN', 'PRY', 'NLD', None, 'PHL', 'POL', 'POL', None, 'PRT', 'PER', None, None, 'ROU', 'GBR', 'GBR', 'FRA', 'DEU', None, None, None, None, 'DOM', None, None, 'SRB', 'SGP', 'SVK', 'SVN', 'LKA', 'LKA', 'CHE', 'CHE', 'SWE', 'SWE', None, 'SEN', 'SEN', None, None, None, None, None, 'THA', 'TGO', 'TUN', 'TUR', 'UKR', 'UKR', 'URY', None, None, None, None, None, None, None, 'EGY', 'EGY', 'USA', 'USA', 'USA']
for i in range(len(cfc)):
    cfc.loc[i, 'CodePays'] = list_cp[i]

df['Date de sortie'] = df['Date de sortie'].replace('Non renseigné', 0)
df['Date de sortie'] = df['Date de sortie'].replace(np.nan, 0)
idx0 = df[df['Date de sortie'] == 0].index

df_copy = df.copy()
df_copy.drop(idx0, inplace = True)

df_copy['Date de sortie'] = df_copy['Date de sortie'].astype(int)
df2 = df_copy.sort_values(by='Date de sortie')
test2 = plt.figure(figsize=(10, 6))
ax2 = sns.countplot(x='Date de sortie', hue="Format", data=df2, palette='Set1')

plt.xlabel('Année de sortie')
plt.ylabel('Format')
plt.title('Graphique des formats en fonction de l\'année de sortie')

# Afficher le graphique
plt.legend(title='Format', loc='upper right')
plt.xticks(rotation=90)
plt.tight_layout()
#plt.show()
st.title(':blue[__Format__] of film over year')
st.pyplot(test2, use_container_width=True)
st.write('We can see that we have 2 types of format : **Court-métrage**, ie short films, and **long-métrage**, ie long films')
st.write('Unfortunately, the majority is **non-renseigné**, ie not known')
st.write('Maybe because back in old years, we did not note correctly the type, and now it is complicated to find it')
format_pays = df.groupby(['Nationalité', 'Format']).size().reset_index(name = 'count')

for i in range(len(format_pays)):
    a = format_pays.loc[i, 'Nationalité']
    arr = a.split(" - ")
    format_pays.loc[i, 'Pays'] = arr[0]


format_pays.loc[format_pays['Pays'].str.contains('Allemagne', case = False), 'Pays'] = 'Allemagne'
format_pays.loc[format_pays['Pays'].str.contains('Canada', case = False), 'Pays'] = 'Canada'
format_pays.loc[format_pays['Pays'].str.contains('Espagne', case = False), 'Pays'] = 'Espagne'
format_pays.loc[format_pays['Pays'].str.contains('France', case = False), 'Pays'] = 'France'
format_pays.loc[format_pays['Pays'].str.contains('Hongrie', case = False), 'Pays'] = 'Hongrie'
format_pays.loc[format_pays['Pays'].str.contains('Pologne', case = False), 'Pays'] = 'Pologne'
format_pays.loc[format_pays['Pays'].str.contains('Royaume-Uni', case = False), 'Pays'] = 'Royaume-Uni'
format_pays.loc[format_pays['Pays'].str.contains('Russie', case = False), 'Pays'] = 'Russie'
format_pays.loc[format_pays['Pays'].str.contains('Égypte', case = False), 'Pays'] = 'Égypte'
format_pays.loc[format_pays['Pays'].str.contains('États-Unis', case = False), 'Pays'] = 'États-Unis'
format_pays.loc[format_pays['Pays'].str.contains('Albanie', case = False), 'Pays'] = 'Albanie'
format_pays.loc[format_pays['Pays'].str.contains('Allemagne', case = False), 'Pays'] = 'Allemagne'
format_pays.loc[format_pays['Pays'].str.contains('Australie', case = False), 'Pays'] = 'Australie'
format_pays.loc[format_pays['Pays'].str.contains('Belgique', case = False), 'Pays'] = 'Belgique'
format_pays.loc[format_pays['Pays'].str.contains('Brésil', case = False), 'Pays'] = 'Brésil'
format_pays.loc[format_pays['Pays'].str.contains('Chine', case = False), 'Pays'] = 'Chine'
format_pays.loc[format_pays['Pays'].str.contains('Danemark', case = False), 'Pays'] = 'Danemark'
format_pays.loc[format_pays['Pays'].str.contains('Grèce', case = False), 'Pays'] = 'Grèce'
format_pays.loc[format_pays['Pays'].str.contains('Irtalie', case = False), 'Pays'] = 'Italie'
format_pays.loc[format_pays['Pays'].str.contains('Italie', case = False), 'Pays'] = 'Italie'
format_pays.loc[format_pays['Pays'].str.contains('Japon', case = False), 'Pays'] = 'Japon'
format_pays.loc[format_pays['Pays'].str.contains('Lettonie', case = False), 'Pays'] = 'Lettonie'
format_pays.loc[format_pays['Pays'].str.contains('Liban', case = False), 'Pays'] = 'Liban'
format_pays.loc[format_pays['Pays'].str.contains('Mexique', case = False), 'Pays'] = 'Mexique'
format_pays.loc[format_pays['Pays'].str.contains('Norvège', case = False), 'Pays'] = 'Norvège'
format_pays.loc[format_pays['Pays'].str.contains('Nouvelle Zélande', case = False), 'Pays'] = 'Nouvelle Zélande'
format_pays.loc[format_pays['Pays'].str.contains('Nouvelle-Zélande', case = False), 'Pays'] = 'Nouvelle Zélande'
format_pays.loc[format_pays['Pays'].str.contains('Sri Lanka', case = False), 'Pays'] = 'Sri Lanka'
format_pays.loc[format_pays['Pays'].str.contains('Sri-Lanka', case = False), 'Pays'] = 'Sri Lanka'
format_pays.loc[format_pays['Pays'].str.contains('Suisse', case = False), 'Pays'] = 'Suisse'
format_pays.loc[format_pays['Pays'].str.contains('Suède', case = False), 'Pays'] = 'Suède'
format_pays.loc[format_pays['Pays'].str.contains('Sénégal', case = False), 'Pays'] = 'Sénégal'
format_pays.loc[format_pays['Pays'].str.contains('Tchécoslovaquie', case = False), 'Pays'] = 'Tchécoslovaquie'
format_pays.loc[format_pays['Pays'].str.contains('Ukraine', case = False), 'Pays'] = 'Ukraine'
format_pays.loc[format_pays['Pays'].str.contains('Vietnam', case = False), 'Pays'] = 'Viêt Nam'
format_pays.loc[format_pays['Pays'].str.contains('Viêt Nam', case = False), 'Pays'] = 'Viêt Nam'
format_pays.loc[format_pays['Pays'].str.contains('Yougoslavie', case = False), 'Pays'] = 'Yougoslavie'
format_pays.loc[format_pays['Pays'].str.contains('États-Uni', case = False), 'Pays'] = 'États-Unis'

for i in range(len(format_pays)):
    for j in range(len(cfc)):
        if format_pays.loc[i, 'Pays'] == cfc.loc[j, 'Pays']:
            format_pays.loc[i, 'Country'] = cfc.loc[j, 'Country']
            format_pays.loc[i, 'CodePays'] = cfc.loc[j, 'CodePays']

fig2 = px.scatter_geo(format_pays, locations="CodePays", color="Format",
                     hover_name="Pays", size="count",
                     projection="natural earth")

#fig2.show()
st.title(':blue[__Format__] of film on a map')
st.plotly_chart(fig2, use_container_width=True)